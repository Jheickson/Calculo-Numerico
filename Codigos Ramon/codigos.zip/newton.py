def f(x):
    return x

def df(x):
    return x

def newton(x0, tol, maxiter):
    iter = 0
    error = tol + 1

    while error > tol and iter < maxiter:
        iter += 1
        dx = -f(x0) / df(x0)
        x = x0 + dx
        error = abs(x - x0)
        x0 = x

        print()

    if error > tol:
        x = None
    
    return x


print(newton(0, 0, 100))
